<?php

require_once(__DIR__ . "/../dao/UsuarioDAO.php");
require_once(__DIR__ . "/../service/PerfilService.php");
require_once(__DIR__ . "/../service/ArquivoService.php");

class PerfilController {
    //objeto
    private UsuarioDAO $usuarioDAO;
    private PerfilService $perfilService;
    private ArquivoService $arquivoService;

    public function __construct() {
        $this->usuarioDAO     = new UsuarioDAO();
        $this->perfilService  = new PerfilService();
        $this->arquivoService = new ArquivoService();
    }
    //método alterar
    public function alterar(array $fotoPerfil){
    //1- validar o arquivo
    $erros = $this->perfilService->validarPerfil($fotoPerfil);
    if($erros){
        return $erros;
    }
    //2- salvar o arquivo em um diretório
    $this->arquivoService->salvarArquivo($fotoPerfil);
    
    //3-atualizar o registro do usuario no bd (caminho)

    return array();
    }
}