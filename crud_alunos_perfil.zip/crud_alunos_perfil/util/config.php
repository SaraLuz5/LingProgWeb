<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "db_alunos");
define("DB_USER", "root");
define("DB_PASSWORD", "");

//Configuração do ambiente
define("AMB_DEV", true);

//Configuração de acesso
define("BASE_URL", "/LingProgWeb/crud_alunos_perfil");

//Configurações de sessão
define("SESSAO_USUARIO_ID", "sessaoUsuId");
define("SESSAO_USUARIO_NOME", "sessaoUsuNome");

///configuração de arquivos
define("DIR_ARQUIVOS",__DIR__ . "/../arquivos");

//C:\xampp\htdocs\LingProgWeb\crud_alunos_perfil\index.php