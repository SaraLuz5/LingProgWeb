<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Autores.php");

class AutoresDAO
{

    public function list()
    {
        $sql = "SELECT * FROM autores";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id)
    {
        $sql = "SELECT * FROM autores WHERE id = ?";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);

        $dados = $stm->fetchAll();
        $autores = $this->map($dados);

        if (! empty($autores))
            return $autores[0];
        else
            return NULL;
    }

    public function insert(Autores $autor)
    {
        try {
            $sql = "INSERT INTO autores (nome, nacionalidade) VALUES (:nome, :nacionalidade)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $autor->getNome());
            $stm->bindValue("nacionalidade", $autor->getNacionalidade());
            $stm->execute();
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o autor, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Autores $autor)
    {
        try {
            $sql = "UPDATE autores SET nome = :nome, nacionalidade = :nacionalidade WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $autor->getNome());
            $stm->bindValue("nacionalidade", $autor->getNacionalidade());
            $stm->bindValue("id", $autor->getId());
            $stm->execute();
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o autor, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id)
    {
        try {
            $sql = "DELETE FROM autores WHERE id = ?";

            $conn = Connection::getConnection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id]);
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao excluir o autor, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados)
    {
        $autores = array();
        foreach ($dados as $d) {
            $autor = new Autores();
            $autor->setId($d["id"]);
            $autor->setNome($d["nome"]);
            $autor->setNacionalidade($d["nacionalidade"]);

            array_push($autores, $autor);
        }
        return $autores;
    }
}
