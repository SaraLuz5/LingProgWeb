<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Livro.php");
require_once(__DIR__ . "/../model/Autores.php");
require_once(__DIR__ . "/../model/Genero.php");

class LivrosDAO
{

    public function list()
    {
        $sql = "SELECT l.*, a.nome nome_autor, a.nacionalidade nacionalidade_autor,
                       g.nome nome_genero
                FROM livros l
                JOIN autores a ON (a.id = l.id_autor)
                JOIN generos g ON (g.id = l.id_genero)";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id)
    {

        $sql = "SELECT l.*, a.nome nome_autor, a.nacionalidade nacionalidade_autor,
                       g.nome nome_genero
                FROM livros l
                JOIN autores a ON (a.id = l.id_autor)
                JOIN generos g ON (g.id = l.id_genero)
                WHERE l.id = ?";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);

        $dados = $stm->fetchAll();
        $livros = $this->map($dados);

        if (! empty($livros))
            return $livros[0];
        else
            return NULL;
    }

    public function insert(livro $livro)
    {
        try {
            $sql = "INSERT INTO livros (titulo, ano_publicado, sinopse, id_autor, id_genero)
                VALUES (:titulo, :ano_publicado, :sinopse, :id_autor, :id_genero)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("titulo", $livro->getTitulo());
            $stm->bindValue("ano_publicado", $livro->getAnoPublicado());
            $stm->bindValue("sinopse", $livro->getSinopse());
            $stm->bindValue("id_autor", $livro->getAutor()->getId());
            $stm->bindValue("id_genero", $livro->getGenero()->getId());
            $stm->execute();
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o livro, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(livro $livro){
        try {
            $sql = "UPDATE livros
                    SET titulo = :titulo, ano_publicado = :ano_publicado,
                    sinopse = :sinopse, id_autor = :id_autor, id_genero = :id_genero
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("titulo", $livro->getTitulo());
            $stm->bindValue("ano_publicado", $livro->getAnoPublicado());
            $stm->bindValue("sinopse", $livro->getSinopse());
            $stm->bindValue("id_autor", $livro->getAutor()->getId());
            $stm->bindValue("id_genero", $livro->getGenero()->getId());
            $stm->bindValue("id", $livro->getId());
            $stm->execute();

        } catch(PDOException $e){
            $erro = "Erro ao salvar o livro, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id)
    {
        try {
            $sql = "DELETE FROM livros WHERE id = ?";

            $conn = Connection::getConnection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id]);
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao excluir o livro, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados)
    {
        $livros = array();
        foreach ($dados as $d) {
            $livro = new livro();
            $livro->setId($d['id']);
            $livro->setTitulo($d["titulo"]);
            $livro->setAnoPublicado($d["ano_publicado"]);
            $livro->setSinopse($d["sinopse"]);

            $autor = new Autores();
            $autor->setId($d["id_autor"]);
            $autor->setNome($d["nome_autor"]);
            $autor->setNacionalidade($d["nacionalidade_autor"]);
            $livro->setAutor($autor);

            $genero = new Genero();
            $genero->setId($d["id_genero"]);
            $genero->setNome($d["nome_genero"]);
            $livro->setGenero($genero);

            array_push($livros, $livro);
        }
        return $livros;
    }
}
