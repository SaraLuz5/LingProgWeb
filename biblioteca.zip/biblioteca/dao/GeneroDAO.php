<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Genero.php");

class GeneroDAO {

    public function list() {
        $sql = "SELECT * FROM generos";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id)
    {
        $sql = "SELECT * FROM generos WHERE id = ?";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);

        $dados = $stm->fetchAll();
        $generos = $this->map($dados);

        if (! empty($generos))
            return $generos[0];
        else
            return NULL;
    }

    public function insert(Genero $genero)
    {
        try {
            $sql = "INSERT INTO generos (nome) VALUES (:nome)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $genero->getNome());
            $stm->execute();
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o gênero, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Genero $genero)
    {
        try {
            $sql = "UPDATE generos SET nome = :nome WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $genero->getNome());
            $stm->bindValue("id", $genero->getId());
            $stm->execute();
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o gênero, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id)
    {
        try {
            $sql = "DELETE FROM generos WHERE id = ?";

            $conn = Connection::getConnection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id]);
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao excluir o gênero, tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
        $generos = array();
        foreach($dados as $d) {

            $genero = new Genero();
            $genero->setId($d["id"]);
            $genero->setNome($d["nome"]);

            array_push($generos, $genero);
        }
        return $generos;
    }

}
