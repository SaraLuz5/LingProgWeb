<?php
require_once(__DIR__ . "/../service/LivroService.php");
require_once(__DIR__ . "/../dao/LivrosDAO.php");

class LivroController
{

    private LivrosDAO $livroDao;
    private LivroService $livroService;

    public function __construct()
    {
        $this->livroDao = new LivrosDAO();
        $this->livroService = new LivroService();
    }

    public function listar()
    {
        return $this->livroDao->list();
    }

    public function buscarPorId(int $id)
    {
        return $this->livroDao->findById($id);
    }

    public function inserir($livro)
    {
        //validar os dados
        $erros = $this->livroService->validar($livro);

        //persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->livroDao->insert($livro);
            if ($erroDAO)
                array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function alterar($livro)
    {
        $erros = $this->livroService->validar($livro);

        //persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->livroDao->update($livro);
            if ($erroDAO)
                array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function excluir(int $id)
    {
        return $this->livroDao->excluir($id);
    }
}
