<?php
require_once(__DIR__ . "/../dao/AutoresDAO.php");

class AutorController
{

    public function listar()
    {
        $autorDao = new AutoresDAO();
        return $autorDao->list();
    }
}
