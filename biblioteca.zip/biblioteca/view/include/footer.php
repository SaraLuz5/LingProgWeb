<footer>
    <div>
        © 2026 Copyright:
        <a href="https://foz.ifpr.edu.br"
            target="blank">IFPR (Campus Foz do Iguaçu)</a>
    </div>
</footer>
<!--Fechamento da tag aberta no header-->
</div>

<script>
    // Alterna o menu em telas pequenas (substitui o JS do Bootstrap)
    document.addEventListener("DOMContentLoaded", function () {
        var toggler = document.querySelector(".navbar-toggler");
        var nav = document.querySelector(".navbar-nav");
        if (toggler && nav) {
            toggler.addEventListener("click", function () {
                nav.classList.toggle("show");
            });
        }
    });
</script>

</body>

</html>