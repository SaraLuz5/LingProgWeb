<?php
require_once(__DIR__ . "/../../util/config.php");
?>
<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biblioteca Virtual </title>
    <link href="<?= BASE_URL ?>/css/style.css" rel="stylesheet">
</head>

<body>

   <div class="container">