<?php
require_once(__DIR__ . "/../../util/config.php");
?>



<nav class="navbar">

    <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">Cadastro de Livros</a>

    <button class="navbar-toggler" type="button" aria-label="Abrir menu">
        &#9776;
    </button>

    <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navDropDown">Cadastros</a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?= BASE_URL ?>/view/livros/listar.php">Livros</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Sobre</a>
        </li>
    </ul>
</nav>