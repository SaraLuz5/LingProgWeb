<?php
require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../../controller/AutorController.php");
require_once(__DIR__ . "/../../controller/GeneroController.php");

$autorController = new AutorController();
$autores = $autorController->listar();

$generoController = new GeneroController();
$generos = $generoController->listar();
?>

</style>

<h3><?= $livro && $livro->getId() > 0 ? "Alterar" : "Inserir" ?> Livros</h3>

<div class="form-row">
    <div class="form-col">

        <!-- Validação obrigatória feita no back-end (LivroService::validar), sem "required" no HTML -->
        <form action="" method="POST">

            <div>
                <label for="txtTitulo">Título:</label>
                <input type="text" id="txtTitulo" name="titulo" placeholder="Informe o título"
                    value="<?= $livro ? $livro->getTitulo() : '' ?>">
            </div>

            <div>
                <label for="txtAno">Ano de publicação: </label>
                <input type="number" id="txtAno" placeholder="Informe o ano de publicação" name="ano_publicado"
                    value="<?= $livro != null ? $livro->getAnoPublicado() : '' ?>">
            </div>

            <div>
                <label for="selAutor">Autor: </label>
                <select name="autor" id="selAutor">
                    <option value="">-----Selecione-----</option>

                    <?php foreach ($autores as $a): ?>
                        <option value="<?= $a->getId() ?>"
                            <?php
                            if ($livro && $livro->getAutor()->getId() == $a->getId())
                                echo "selected";
                            ?>>
                            <?= $a->getNome() ?></option>
                    <?php endforeach; ?>

                </select>
            </div>

            <div>
                <label for="selGenero">Gênero: </label>
                <select name="genero" id="selGenero">
                    <option value="">-----Selecione-----</option>

                    <?php foreach ($generos as $g): ?>
                        <option value="<?= $g->getId() ?>"
                            <?php
                            if ($livro && $livro->getGenero() && $livro->getGenero()->getId() == $g->getId())
                                echo "selected";
                            ?>>
                            <?= $g->getNome() ?></option>
                    <?php endforeach; ?>

                </select>
            </div>

             <div>
                <label for="txtSinopse">Sinopse: </label>
                <textarea id="txtSinopse" name="sinopse" placeholder="Escreva uma breve sinopse"
                    rows="4"><?= $livro ? $livro->getSinopse() : '' ?></textarea>
            </div>

            <div>
                <input type="hidden" name="id"
                    value="<?= $livro ? $livro->getId() : 0 ?>">
            </div>

            <br>

            <div>
                <button type="submit">Gravar</button>
            </div>
        </form>
    </div>
    <div class="form-col">

        <?php if ($msgErro): ?>

            <div class="erro">
                <?= $msgErro; ?>
            </div>

        <?php endif; ?>
    </div>
</div>

<br>
<a href="listar.php">Voltar</a>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>
