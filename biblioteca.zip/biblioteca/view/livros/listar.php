<?php
require_once(__DIR__ . "/../../controller/LivroController.php");

//Buscar os livros -> origem: base de dados
$livroCont = new LivroController();
$livros = $livroCont->listar();

//Inclui o cabeçalho da página
require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>

<h3>Listagem de livros</h3>

<table >

    <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Ano</th>
        <th>Autor</th>
        <th>Gênero</th>
        <th>Sinopse</th>
        <th></th>
        <th></th>
    </tr>

    <?php foreach ($livros as $l): ?>
        <tr>
            <td><?= $l->getId() ?></td>
            <td><?= $l->getTitulo() ?></td>
            <td><?= $l->getAnoPublicado() ?></td>
            <td><?= $l->getAutor()->getNome() ?></td>
            <td><?= $l->getGenero()->getNome() ?></td>
            <td><?= $l->getSinopse() ?></td>
            <td>
                <a href="alterar.php?id=<?= $l->getId() ?>">
                    <img src="../../img/btn_editar.png" alt="">
                </a>
            </td>
            <td>
                <a href="excluir.php?id=<?= $l->getId() ?>"
                    onclick="return confirm('Confirma a exclusão?');">
                    <img src="../../img/btn_excluir.png" alt="">
                </a>
            </td>
        </tr>
    <?php endforeach; ?>

</table>

<br>

<a href="inserir.php" >Inserir</a>

<?php
//Inclui o rodapé da página
require_once(__DIR__ . "/../include/footer.php");
?>
