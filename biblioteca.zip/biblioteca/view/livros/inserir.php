<?php
require_once(__DIR__ . "/../../model/Livro.php");
require_once(__DIR__ . "/../../model/Autores.php");
require_once(__DIR__ . "/../../model/Genero.php");
require_once(__DIR__ . "/../../controller/LivroController.php");

$msgErro = "";
$livro = NULL;

//verifica se o formulario ja foi submetido
if (isset($_POST['titulo'])) {

    //capturar e validar (no back-end) o preenchimento básico dos campos
    $titulo = trim($_POST['titulo']) ? trim($_POST['titulo']) : NULL;
    $anoPublicado = is_numeric($_POST['ano_publicado']) ? (int) $_POST['ano_publicado'] : NULL;
    $sinopse = trim($_POST['sinopse']) ? trim($_POST['sinopse']) : NULL;
    $idAutor = is_numeric($_POST['autor']) ? (int) $_POST['autor'] : NULL;
    $idGenero = is_numeric($_POST['genero']) ? (int) $_POST['genero'] : NULL;

    //criar um objeto livro pra persisti-lo

    $livro = new livro();
    $livro->setId(0);
    $livro->setTitulo($titulo);
    $livro->setAnoPublicado($anoPublicado);
    $livro->setSinopse($sinopse);

    $autor = new Autores();
    $autor->setId($idAutor ?? 0);
    $livro->setAutor($autor);

    $genero = new Genero();
    $genero->setId($idGenero);
    $livro->setGenero($genero);

    //validar os dados e persistir o objeto (a validação completa ocorre no LivroController/LivroService)

    $livroCont = new LivroController();
    $erros = $livroCont->inserir($livro);

    if (empty($erros))
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
