<?php
require_once(__DIR__ . "/../../controller/LivroController.php");

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $livroCont = new LivroController();
    $erro = $livroCont->excluir($id);

    if (! $erro) {
        header("location: listar.php");
    } else {
        echo $erro;
        echo "<br><a href='listar.php'>Voltar</a>";
    }
} else {
    echo "ID do livro não informado!<br>";
    echo "<a href='listar.php'>Voltar</a>";
}
