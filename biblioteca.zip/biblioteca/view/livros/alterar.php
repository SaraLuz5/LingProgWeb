<?php
require_once(__DIR__ . "/../../model/Livro.php");
require_once(__DIR__ . "/../../model/Autores.php");
require_once(__DIR__ . "/../../model/Genero.php");
require_once(__DIR__ . "/../../controller/LivroController.php");

$msgErro = "";
$livro = NULL;
$livroCont = new LivroController();

//Verifica se o usuario ja clicou no gravar
if (isset($_POST['titulo'])) {
    //atualizar o livro no banco de dados

    $id = is_numeric($_POST["id"]) ? (int) $_POST["id"] : 0;
    $titulo = trim($_POST['titulo']) ? trim($_POST['titulo']) : NULL;
    $anoPublicado = is_numeric($_POST['ano_publicado']) ? (int) $_POST['ano_publicado'] : NULL;
    $sinopse = trim($_POST['sinopse']) ? trim($_POST['sinopse']) : NULL;
    $idAutor = is_numeric($_POST['autor']) ? (int) $_POST['autor'] : NULL;
    $idGenero = is_numeric($_POST['genero']) ? (int) $_POST['genero'] : NULL;

    //criar um objeto livro pra persisti-lo

    $livro = new livro();
    $livro->setId($id);
    $livro->setTitulo($titulo);
    $livro->setAnoPublicado($anoPublicado);
    $livro->setSinopse($sinopse);

    $autor = new Autores();
    $autor->setId($idAutor ?? 0);
    $livro->setAutor($autor);

    $genero = new Genero();
    $genero->setId($idGenero);
    $livro->setGenero($genero);

    //Validar e Salvar os dados no banco
    $erros = $livroCont->alterar($livro);
    if (empty($erros))
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
} else {
    //Carregar os dados do livro a ser alterado
    $id = 0;
    if (isset($_GET['id']))
        $id = (int) $_GET['id'];

    $livro = $livroCont->buscarPorId($id);
    if (! $livro) {
        echo "ID do livro não informado!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}

require_once(__DIR__ . "/form.php");
