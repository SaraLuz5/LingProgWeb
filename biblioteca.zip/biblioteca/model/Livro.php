<?php
require_once(__DIR__ . "/Autores.php");
require_once(__DIR__ . "/Genero.php");

class livro
{
    private ?int $id;
    private ?string $titulo;
    private ?int $anoPublicado;
    private ?string $sinopse;
    private ?Autores $autor;
    private ?Genero $genero;



    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of titulo
     */
    public function getTitulo(): ?string
    {
        return $this->titulo;
    }

    /**
     * Set the value of titulo
     */
    public function setTitulo(?string $titulo): self
    {
        $this->titulo = $titulo;

        return $this;
    }

    /**
     * Get the value of anoPublicado
     */
    public function getAnoPublicado(): ?int
    {
        return $this->anoPublicado;
    }

    /**
     * Set the value of anoPublicado
     */
    public function setAnoPublicado(?int $anoPublicado): self
    {
        $this->anoPublicado = $anoPublicado;

        return $this;
    }

    /**
     * Get the value of sinopse
     */
    public function getSinopse(): ?string
    {
        return $this->sinopse;
    }

    /**
     * Set the value of sinopse
     */
    public function setSinopse(?string $sinopse): self
    {
        $this->sinopse = $sinopse;

        return $this;
    }

    /**
     * Get the value of autor
     */
    public function getAutor(): ?Autores
    {
        return $this->autor;
    }

    /**
     * Set the value of autor
     */
    public function setAutor(?Autores $autor): self
    {
        $this->autor = $autor;

        return $this;
    }

    /**
     * Get the value of genero
     */
    public function getGenero(): ?Genero
    {
        return $this->genero;
    }

    /**
     * Set the value of genero
     */
    public function setGenero(?Genero $genero): self
    {
        $this->genero = $genero;

        return $this;
    }
}
