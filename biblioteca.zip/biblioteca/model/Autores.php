<?php

class Autores{

private ?int $id;
private ?string $nome;
private ?string $nacionalidade;



/**
 * Get the value of id
 */
public function getId(): ?int
{
return $this->id;
}

/**
 * Set the value of id
 */
public function setId(?int $id): self
{
$this->id = $id;

return $this;
}

/**
 * Get the value of nome
 */
public function getNome(): ?string
{
return $this->nome;
}

/**
 * Set the value of nome
 */
public function setNome(?string $nome): self
{
$this->nome = $nome;

return $this;
}

/**
 * Get the value of nacionalidade
 */
public function getNacionalidade(): ?string
{
return $this->nacionalidade;
}

/**
 * Set the value of nacionalidade
 */
public function setNacionalidade(?string $nacionalidade): self
{
$this->nacionalidade = $nacionalidade;

return $this;
}
}