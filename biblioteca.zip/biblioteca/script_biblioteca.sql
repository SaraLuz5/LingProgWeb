
/* TABELA generos */
CREATE TABLE generos ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome VARCHAR (70) NOT NULL,
  CONSTRAINT pk_genero PRIMARY KEY (id) 
);

/* INSERTs genero */
INSERT INTO generos (nome) VALUES ('Literatura');
INSERT INTO generos (nome) VALUES ('História');
INSERT INTO generos (nome) VALUES ('Ciêcias');
INSERT INTO generos (nome) VALUES ('Ficção');
INSERT INTO generos (nome) VALUES ('Romance');

/* TABELA autores*/
CREATE TABLE autores(
  id int AUTO_INCREMENT NOT NULL,
  nome Varchar (70) NOT NULL,
  nacionalidade VARCHAR(50),
  CONSTRAINT pk_autores PRIMARY KEY (id)
);

/*INSERT autores*/
INSERT INTO autores (nome, nacionalidade) VALUES ('George Orwell', 'Britânico');
INSERT INTO autores (nome, nacionalidade) VALUES ('Clarice Linspector', 'Brasileira');
INSERT INTO autores (nome, nacionalidade) VALUES ('J. K. Rowling', 'Britânico');
INSERT INTO autores (nome, nacionalidade) VALUES ('Stephen Hawking', 'Inglês');
INSERT INTO autores (nome, nacionalidade) VALUES ('Nelson Rodriguês', 'Brasileiro');


/* TABELA livros */
CREATE TABLE livros ( 
  id int AUTO_INCREMENT NOT NULL, 
  titulo varchar(150) NOT NULL,
  ano_publicado YEAR,
  sinopse TEXT,
  id_autor int NOT NULL,
  id_genero int NOT NULL,
  CONSTRAINT pk_livros PRIMARY KEY (id) 
);
ALTER TABLE livros ADD CONSTRAINT fk_livro_genero FOREIGN KEY (id_genero) REFERENCES generos (id),
                   ADD CONSTRAINT fk_livro_autor FOREIGN KEY (id_autor) REFERENCES autores(id);
