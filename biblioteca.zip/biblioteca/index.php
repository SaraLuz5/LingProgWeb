<?php
require_once(__DIR__ . "/view/include/header.php");
require_once(__DIR__ . "/view/include/menu.php");
?>

<div class="card">
    <img src="img/card_alunos.png"
        style="max-width: 200px; height:auto;" />

    <div>
        <h5>Livros</h5>
    </div>

    <ul>
        <li>
            <a href="<?= BASE_URL ?>/view/livros/listar.php">
                Listagem dos Livros</a>
        </li>
    </ul>
</div>
</div>
</div>
<?php
require_once(__DIR__ . "/view/include/footer.php");
?>