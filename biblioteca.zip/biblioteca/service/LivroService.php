<?php
require_once(__DIR__ . "/../model/Livro.php");

class LivroService
{

    public function validar($livro)
    {
        $erros = array();

        if (! $livro->getTitulo())
            array_push($erros, "Informe o título do livro!");

        if (! $livro->getAnoPublicado())
            array_push($erros, "Informe o ano de publicação!");
        else if ($livro->getAnoPublicado() < 1000 || $livro->getAnoPublicado() > (int) date("Y"))
            array_push($erros, "Informe um ano de publicação válido!");

        if (! $livro->getSinopse())
            array_push($erros, "Escreva uma breve sinopse!");

        if (! $livro->getAutor() || ! $livro->getAutor()->getId())
            array_push($erros, "Informe o autor!");

        if (! $livro->getGenero() || ! $livro->getGenero()->getId())
            array_push($erros, "Informe o gênero!");

        return $erros;
    }
}
